package com.Task.MiniProject.Exception;

public class IdAlreadyExistException extends RuntimeException{
    public IdAlreadyExistException(String message){
        super(message);
    }
}
